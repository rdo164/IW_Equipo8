# IW_Grupo8
Django project.
---
## [Repositorio de Github:](https://github.com/rdo164/IW_Grupo8) 
---
## Estructura de datos

- ### README.md
- ### [D_Tubular](https://github.com/rdo164/IW_Grupo8/tree/master/D_Tubular)/ 
    - ### [D_Tubular](https://github.com/rdo164/IW_Grupo8/tree/master/D_Tubular//D_Tubular)/ 
      - ##### [__pycache__](https://github.com/rdo164/IW_Grupo8/tree/master/D_Tubular/D_Tubular/__pycache__)
      - ##### asgi.py
      - ##### settings.py
      - ##### urls.py
      - ##### wsgi.py
    
  - ### [appdeustub](https://github.com/rdo164/IW_Grupo8/tree/master/D_Tubular/appdeustutub)/ 
    - ##### [__pycache__](https://github.com/rdo164/IW_Grupo8/tree/master/D_Tubular/appdeustutub/__pycache__)
    - ##### [migrations](https://github.com/rdo164/IW_Grupo8/tree/master/D_Tubular/appdeustutub/migrations)
    - ##### [templates](https://github.com/rdo164/IW_Grupo8/tree/master/D_Tubular/appdeustutub/templates)
    - ##### __init__.py
    - ##### admin.py
    - ##### apps.py
    - ##### forms.py
    - ##### models.py
    - ##### tests.py
    - ##### urls.py
    - ##### views.py
  
  - ### [static](https://github.com/rdo164/IW_Grupo8/tree/master/D_Tubular/static)/ 
    - ##### [css](https://github.com/rdo164/IW_Equipo8/tree/master/D_Tubular/static/css)
    - ##### [images](https://github.com/rdo164/IW_Equipo8/tree/master/D_Tubular/static/images)

  - ### db.sqlite3 
  - ### manage.py
    
---
## Funcionalidades adicionales
> ### **Borrar**, **Añadir** y **Actualizar** :
> - Empleado 



